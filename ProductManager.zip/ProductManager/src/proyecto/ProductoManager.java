package proyecto;

import java.util.ArrayList;

public class ProductoManager {
	
    private ArrayList<Producto> listaProductos = new ArrayList<>();

    public void agregarProducto(Producto producto) {
        listaProductos.add(producto);
    }

    public ArrayList<Producto> getProductos() {
        return listaProductos;
    }
}
