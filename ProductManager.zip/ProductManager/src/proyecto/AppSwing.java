package proyecto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class AppSwing {
    private static ArrayList<Producto> productos = new ArrayList<>();
    private static JTable tabla;
    private static DefaultTableModel modeloTabla;
    private static final String ARCHIVO = "productos.txt";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> crearGUI());
        cargarDesdeArchivo();
    }

    private static void crearGUI() {
        JFrame frame = new JFrame("Gestor de Productos");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        JTextField txtId = new JTextField(5);
        JTextField txtNombre = new JTextField(10);
        JTextField txtPrecio = new JTextField(7);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnMostrar = new JButton("Mostrar");
        JButton btnGuardar = new JButton("Guardar");
        JButton btnBuscar = new JButton("Buscar/Editar");

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Precio"}, 0);
        tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        scrollPane.setPreferredSize(new Dimension(450, 200));

        panel.add(new JLabel("ID:"));
        panel.add(txtId);
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNombre);
        panel.add(new JLabel("Precio:"));
        panel.add(txtPrecio);
        panel.add(btnAgregar);
        panel.add(btnMostrar);
        panel.add(btnGuardar);
        panel.add(btnBuscar);
        panel.add(scrollPane);

        btnAgregar.addActionListener(e -> {
            try {
                String id = txtId.getText();
                String nombre = txtNombre.getText();
                double precio = Double.parseDouble(txtPrecio.getText());
                productos.add(new Producto(id, nombre, precio));
                JOptionPane.showMessageDialog(frame, "Producto agregado");
                txtId.setText(""); txtNombre.setText(""); txtPrecio.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Precio inválido");
            }
        });

        btnMostrar.addActionListener(e -> {
            modeloTabla.setRowCount(0);
            for (Producto p : productos) {
                modeloTabla.addRow(new Object[]{p.getId(), p.getNombre(), p.getPrecio()});
            }
        });

        btnGuardar.addActionListener(e -> guardarEnArchivo());

        btnBuscar.addActionListener(e -> {
            String idBuscar = JOptionPane.showInputDialog("Ingrese el ID del producto a buscar:");
            for (Producto p : productos) {
                if (p.getId().equals(idBuscar)) {
                    String nuevoNombre = JOptionPane.showInputDialog("Nuevo nombre:", p.getNombre());
                    String nuevoPrecio = JOptionPane.showInputDialog("Nuevo precio:", p.getPrecio());
                    p.setNombre(nuevoNombre);
                    p.setPrecio(Double.parseDouble(nuevoPrecio));
                    JOptionPane.showMessageDialog(frame, "Producto actualizado");
                    return;
                }
            }
            JOptionPane.showMessageDialog(frame, "Producto no encontrado");
        });

        frame.add(panel);
        frame.setVisible(true);
    }

    private static void guardarEnArchivo() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO))) {
            for (Producto p : productos) {
                writer.println(p);
            }
            JOptionPane.showMessageDialog(null, "Productos guardados en archivo");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al guardar archivo");
        }
    }

    private static void cargarDesdeArchivo() {
        File file = new File(ARCHIVO);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                productos.add(Producto.fromString(linea));
            }
        } catch (IOException e) {
            System.out.println("Error al leer archivo");
        }
    }
}
